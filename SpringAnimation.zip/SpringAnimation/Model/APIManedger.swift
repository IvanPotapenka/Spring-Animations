//
//  APIManedger.swift
//  SpringAnimation
//
//  Created by asus on 2/28/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import Foundation


class TypeAnimations {
    
    static let shared = TypeAnimations()
    
    var animation = [
    "pop",
    "morph",
    "squeeze",
    "wobble",
    "swing",
    "flipX",
    "flipY",
    "fall",
    "squeezeLeft",
    "squeezeRight",
    "squeezeDown",
    "squeezeUp",
    "slideLeft",
    "slideRight",
    "slideDown",
    "slideUp",
    "fadeIn",
    "fadeOut",
    "fadeInLeft",
    "fadeInRight",
    "fadeInDown",
    "fadeInUp",
    "zoomIn",
    "zoomOut",
    "flash" ]
    
    var curve = [
        "spring",
        "linear",
        "easeIn",
        "easeOut",
        "easeInOut",
        "spring",
        "linear",
        "easeIn",
        "easeOut",
        "easeInOut",
        "spring",
        "linear",
        "easeIn",
        "easeOut",
        "easeInOut",
        "spring",
        "linear",
        "easeIn",
        "easeOut",
        "easeInOut",
        "spring",
        "linear",
        "easeIn",
        "easeOut",
        "easeInOut"    ]
    
    
}
