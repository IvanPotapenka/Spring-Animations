//
//  Animations.swift
//  SpringAnimation
//
//  Created by asus on 2/27/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import Spring


struct DiscribeAnimations {
    
    let animation: String
    let curve: String
    let duretion: CGFloat
    let delay: CGFloat
    
    
    static func createAnimations() -> [DiscribeAnimations] {
       
        var animations: [DiscribeAnimations] = []
        
        let nameAnimations = TypeAnimations.shared.animation.shuffled()
        let nameCurve = TypeAnimations.shared.curve.shuffled()
        
        
        for index in 0 ..< nameAnimations.count {
            
            let namberDuration = CGFloat(Double.random(in: 0...4))
            let namberDelay = CGFloat(Double.random(in: 0...4))

            let animation = DiscribeAnimations(animation: nameAnimations[index], curve: nameCurve[index], duretion: namberDuration, delay: namberDelay)
            
            animations.append(animation)
            
        }
        return animations
    }

}





