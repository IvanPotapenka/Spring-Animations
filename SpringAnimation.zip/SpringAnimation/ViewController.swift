//
//  ViewController.swift
//  SpringAnimation
//
//  Created by asus on 2/27/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import Spring

class ViewController: UIViewController {

    @IBOutlet var pictureAnimation: SpringView!
    @IBOutlet var nameAnimation: SpringLabel!
    @IBOutlet var paramOne: SpringLabel!
    @IBOutlet var paramTwo: SpringLabel!
    @IBOutlet var paramThree: SpringLabel!
    @IBOutlet var buttonAnimation: SpringButton!
    @IBOutlet var nameCurve: SpringLabel!
    @IBOutlet var valueDuration: SpringLabel!
    @IBOutlet var valueDelay: SpringLabel!
 
    
    let names = DiscribeAnimations.createAnimations()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
   
    setColors()
    setColorsText()
    geometryParam()
    setNamesText()
   
    }
     //MARK: - Set geometry for view
    
    func geometryParam() {
        pictureAnimation.layer.cornerRadius = 15
        buttonAnimation.layer.cornerRadius = 5
    }

    //MARK: - Set colors for text
    
    func setColorsText() {
        nameAnimation.textColor = .white
        paramOne.textColor = .white
        paramTwo.textColor = .white
        paramThree.textColor = .white
        buttonAnimation.tintColor = .white
        valueDelay.textColor = .blue
        valueDuration.textColor = .blue
        nameCurve.textColor = .blue
        
    }

    //MARK: - Set names for text
    
    func setNamesText() {
        nameAnimation.text = "Animation"
        paramOne.text = "Durition"
        paramTwo.text = "Delya"
        paramThree.text = "Curve"
        buttonAnimation.setTitle("Run Animation", for: .normal)
        
        nameCurve.text = ""
        valueDuration.text = "0"
        valueDelay.text = "0"
    }
    
    //MARK: - Set colors for view
    
    func setColors()  {
        pictureAnimation.backgroundColor = .green
        buttonAnimation.backgroundColor = .green
    }
   
    var currentAnimation = 0
    func changeIndexAnimation()  {
        if currentAnimation == (names.count - 1) {
            currentAnimation = 0
        } else {
            currentAnimation += 1
        }
    }
    
    //MARK: - Press Button for Animation
    
    @IBAction func pressButtonAnimation() {
        
        changeIndexAnimation()
        buttonAnimation.setTitle(names[currentAnimation].animation, for: .normal)
        pictureAnimation.autostart = true
        nameAnimation.text = names[currentAnimation].animation
        nameCurve.text = names[currentAnimation].curve
        valueDuration.text = String(format: "%.1f", names[currentAnimation].duretion)
        valueDelay.text = String(format: "%.1f", names[currentAnimation].delay)
        pictureAnimation.animation = names[currentAnimation].animation
        pictureAnimation.curve = names[currentAnimation].curve
        pictureAnimation.duration = names[currentAnimation].duretion
        pictureAnimation.delay = names[currentAnimation].delay
        pictureAnimation.animate()
        
    }
}

